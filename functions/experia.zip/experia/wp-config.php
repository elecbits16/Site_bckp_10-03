<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'experia17');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'K2C`OQ!iD;7kwjP~D%U`O>g<oir#Kd_afq!LUNCK>zuQkV^S9TFmzo@<48~3z@m(');
define('SECURE_AUTH_KEY',  '/k(rgD#%79{::Pq+]-5cBxWblo3Wrp;3;k0emlg9A#jf&F]]];AY^}oM|7-!CUws');
define('LOGGED_IN_KEY',    'IGJ>83Eehgx,VYO+FPo9ul9e=~2%g`M}X<YGUc&10~c}+Q9ZukZ=*~/6R@;AL4xR');
define('NONCE_KEY',        'Dx3?NU76q^FT(^Z2nC%R[]c;F/Kl@osg@I*eD]rmJ`Et=Hsw2Enw9cmz!;Ko23dQ');
define('AUTH_SALT',        '34hq1n9eJrde5{AOq0aK-lWN:OHCK7?ZO#r@-k2XZ:>85#S?:i,cj[.Pf!n}3/Lj');
define('SECURE_AUTH_SALT', 's_NDPQ~xTT{/+kls;&C!+/=3[:FEuy/lh1U+Ibsuzt9*<^hbt54/ufgdG?W=rc@w');
define('LOGGED_IN_SALT',   'QNou[+ALOy_$V9Ds7w}bA[j,xv?hI1k79pfp^=)P-<M!>QbQL>F:YWPklp`o.Att');
define('NONCE_SALT',       '_4M>H~_lxeR_H^oYzMm_(gEHz{~$o9;-fHD!oB@(ot$s^%;Xv%T5kd|ldU(-Evx<');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
