<?php
$myfile = fopen("tweet.txt", "r") or die("Unable to open file!");
$reader = fread($myfile,filesize("tweet.txt"));
$writer_1 = strip_tags($reader, '<br/>');
fwrite($myfile,$writer_1);

fclose($myfile);
 


?>