<!DOCTYPE html>
<html lang="en">
    <head> 
		<meta name="viewport" content="width=device-width, initial-scale=1">

         <link rel="stylesheet" type="text/css" href="form.css">
			<!-- Website Font style -->
	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
		<link rel="stylesheet" href="style.css">
		  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

		<!-- Google Fonts -->
		<link href='https://fonts.googleapis.com/css?family=Passion+One' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>

		<title>Twitter API</title>
	</head>
	<body>
		<div class="container">
			<div class="row main">
				<div class="main-login main-center">
				<h5>Create Tweets.</h5>
					<form class="" method="post" action="">
						
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Tag you want to search</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="tag" id="name"  placeholder="#hashtag" required/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Tweet Count (Not more than 500)</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
									<input type="number" class="form-control" name="tw_count" id="email"  placeholder="Count" required/>
								</div>
							</div>
						</div>

				<!--		<div class="form-group">
							<label for="username" class="cols-sm-2 control-label">Username</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="username" id="username"  placeholder="Enter your Username"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="password" class="cols-sm-2 control-label">Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
									<input type="password" class="form-control" name="password" id="password"  placeholder="Enter your Password"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="confirm" class="cols-sm-2 control-label">Confirm Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
									<input type="password" class="form-control" name="confirm" id="confirm"  placeholder="Confirm your Password"/>
								</div>
							</div>
						</div> -->

						<div class="form-group ">
							 
					 <button  type="submit" id="button" class="btn btn-info btn-lg"  name="update">Submit</button> 
  
</div>
						
						</div>
						
					</form>
				</div>
			</div>
		</div>

<?php

require"twitteroauth/autoload.php";
use Abraham\TwitterOAuth\TwitterOAuth;


$show_modal = false;

if (isset($_POST['update'])) {

	$hashtag = $_POST['tag'];
	$t_count = $_POST['tw_count'];


$consumer_key = 'vEQwA3v0giwOk1yHQ1K0te9Ky';
$consumer_secret= 'ZTJa8KM5SlWqkMCiLokyhL2qaAckvqISBfBWqAsPOLeC6tRe4e';
$access_token = '767306187511586816-u4zetTbkUHxKodveA4QApmeGK5JPeqL';
$access_token_secret = 'QyNSrqKpB9hte7x6TSDik6VE9PaPl40fCfbrIepf2HD7r';


//include library



//Connect to API
$connection = new TwitterOAuth($consumer_key, $consumer_secret, $access_token, $access_token_secret);
$content = $connection -> get("account/verify_credentials");



//$new_status = $connection -> post("statuses/update", ["status"=>"chill"]);

$statuses = $connection -> get("statuses/user_timeline", ["count"=>0,"exclude_replies"=>true]);
$statuses1 = $connection->get("search/tweets", ["q" => $hashtag, "count"=> $t_count]);



 $var =  print_r($statuses1, true);



//echo substr_count($var, '[text] => RT');
$text_count = substr_count($var, '[text] => RT');
//echo "<br>";
//echo substr_count($var, '[truncated] =>');
$trun_count = substr_count($var, '[truncated] =>');
$original_count = $trun_count - $text_count;
//echo "<br>";
//echo $original_count;

 $myfile = fopen("D:/saurav/elecbits original/matlabp/tweet.txt", "w") or die("Unable to open file!");
$myfile1 = fopen("tweet.txt", "w") or die("Unable to open file!");

for ($i=0; $i < $trun_count ; $i++) { 
$trun_dist = explode("[truncated] =>", $var);

  $text_info_count = substr_count($trun_dist[$i], '[text] =>'); 

//  echo "<br>";
 
  //echo $text_info_count;
  // echo "<br>";

 
         
         	$tweets = explode("[text] => ", $trun_dist[$i]);
         	// echo "<br>";
     	 


if (substr_count($trun_dist[$i], 'RT @') == 0) {

	$tweets_write =  trim($tweets[$text_info_count]);

	//echo $real_value;

$delimiter = "|";
fwrite($myfile, ($tweets_write.$delimiter));
fwrite($myfile1, ($tweets_write.$delimiter));
	
}





         	   
  

}

if (fclose($myfile)) {
	

  echo "<script>alert('  $original_count original Tweets are collected , $text_count Retweets are denied.')</script>";
  

  echo "<script>window.open('tweet.txt', '_blank', 'toolbar=yes, location=yes, status=yes, menubar=yes, scrollbars=yes')</script>";


}
/*{
	for ($i=0; $i < $trun_count ; $i++) { 
	
       $text_info_count = substr_count($trun_dist[$i], '[text] => RT');  

     echo $text_info_count;


       /*for ($j=0; $j < $text_info_count ; $j++) { 
         	
         	$tweets = explode("[text] => ", $trun_dist[$i]);

         	echo  $tweets[$text_info_count];

         }  


     

	}
    

}
*/


}

?>






		 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->



	</body>
</html>
