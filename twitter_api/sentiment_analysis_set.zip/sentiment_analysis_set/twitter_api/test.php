<?php
session_start();
require_once("twitteroauth/autoload.php"); //Path to twitteroauth library
 
$twitteruser = "elecbits16";
$notweets = 30;
$consumerkey = "vEQwA3v0giwOk1yHQ1K0te9Ky";
$consumersecret = "ZTJa8KM5SlWqkMCiLokyhL2qaAckvqISBfBWqAsPOLeC6tRe4e";
$accesstoken = "767306187511586816-u4zetTbkUHxKodveA4QApmeGK5JPeqL";
$accesstokensecret = "QyNSrqKpB9hte7x6TSDik6VE9PaPl40fCfbrIepf2HD7r";
 
use Abraham\TwitterOAuth\TwitterOAuth;

//Connect to API
$connection = new TwitterOAuth($consumer_key, $consumer_secret, $access_token, $access_token_secret);
$content = $connection -> get("account/verify_credentials");



//$new_status = $connection -> post("statuses/update", ["status"=>"chill"]);

$statuses = $connection -> get("statuses/user_timeline", ["count"=>0,"exclude_replies"=>true]);
$statuses1 = $connection->get("search/tweets", ["q" => "rpsvsmi", "count"=> 20]);
 
print_r($statuses1);


?>